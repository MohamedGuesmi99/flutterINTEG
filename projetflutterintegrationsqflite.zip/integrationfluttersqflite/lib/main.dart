import 'package:flutter/material.dart';
import './ajoutMedicament.dart';
import 'database_helper.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  Widget build(BuildContext context) {
    return MaterialApp(
      routes: {
        '/listMed': (context) => ListMedicaments(),
      },
      initialRoute: '/listMed',
    );
  }
}

class ListMedicaments extends StatefulWidget {
  @override
  _ListMedicamentsState createState() => _ListMedicamentsState();
}

class _ListMedicamentsState extends State<ListMedicaments> {
  late List<Medicament> medicaments;

  @override
  void initState() {
    super.initState();
    _refreshMedicamentList();
  }

  void _refreshMedicamentList() async {
    medicaments = await DatabaseHelper().getMedicaments();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Medicament List'),
      ),
      body: ListView.builder(
        itemCount: medicaments.length,
        itemBuilder: (context, index) {
          final medicament = medicaments[index];
          return Card(
            elevation: 4,
            margin: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
            child: ListTile(
              leading: Icon(
                Icons.arrow_right,
                color: Colors.orange,
                size: 20,
              ),
              title: Text(
                medicament.nom ?? 'A/N',
                style: TextStyle(
                  fontSize: 20,
                  color: Colors.black,
                ),
              ),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Posologie: ${medicament.posologie}'),
                  Text('DateD: ${medicament.dateD}'),
                  Text('Dosage: ${medicament.dosage}'),
                  Text('Prix: ${medicament.prix}'),
                  Text('DateP: ${medicament.dateP}'),
                  Text('NbrPacket: ${medicament.nbrPacket}'),
                ],
              ),
              onTap: () {
                // Implement actions when tapping on a medicament item
                print('Tapped on ${medicament.nom}');
                _showUpdateDeleteDialog(context, medicament);
              },
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Implement action to add a new medicament
          _showAddDialog(context);
        },
        child: Icon(Icons.add),
      ),
    );
  }

  Future<void> _showAddDialog(BuildContext context) async {
    TextEditingController nomController = TextEditingController();
    TextEditingController posologieController = TextEditingController();
    TextEditingController dateDController = TextEditingController();
    TextEditingController dosageController = TextEditingController();
    TextEditingController prixController = TextEditingController();
    TextEditingController datePController = TextEditingController();
    TextEditingController nbrPacketController = TextEditingController();

    await showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Add Medicament'),
          content: SingleChildScrollView(
            child: Column(
              children: [
                TextField(
                  controller: nomController,
                  decoration: InputDecoration(labelText: 'Nom'),
                ),
                TextField(
                  controller: posologieController,
                  decoration: InputDecoration(labelText: 'Posologie'),
                ),
                TextField(
                  controller: dateDController,
                  decoration: InputDecoration(labelText: 'DateD'),
                ),
                TextField(
                  controller: dosageController,
                  decoration: InputDecoration(labelText: 'Dosage'),
                ),
                TextField(
                  controller: prixController,
                  decoration: InputDecoration(labelText: 'Prix'),
                  keyboardType: TextInputType.number,
                ),
                TextField(
                  controller: datePController,
                  decoration: InputDecoration(labelText: 'DateP'),
                ),
                TextField(
                  controller: nbrPacketController,
                  decoration: InputDecoration(labelText: 'NbrPacket'),
                  keyboardType: TextInputType.number,
                ),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: Text('Save'),
              onPressed: () async {
                Medicament newMedicament = Medicament(
                  nom: nomController.text,
                  posologie: posologieController.text,
                  dateD: dateDController.text,
                  dosage: dosageController.text,
                  prix: double.parse(prixController.text),
                  dateP: datePController.text,
                  nbrPacket: int.parse(nbrPacketController.text),
                );
                await DatabaseHelper().insertMedicament(newMedicament).then((value) {
                  Navigator.of(context).pop(); // Close the dialog
                  _refreshMedicamentList(); // Refresh the medicament list
                });
              },
            ),
          ],
        );
      },
    );
  }

  Future<void> _showUpdateDeleteDialog(BuildContext context, Medicament medicament) async {
    TextEditingController nomController = TextEditingController(text: medicament.nom);
    TextEditingController posologieController = TextEditingController(text: medicament.posologie);
    TextEditingController dateDController = TextEditingController(text: medicament.dateD);
    TextEditingController dosageController = TextEditingController(text: medicament.dosage);
    TextEditingController prixController = TextEditingController(text: medicament.prix.toString());
    TextEditingController datePController = TextEditingController(text: medicament.dateP);
    TextEditingController nbrPacketController = TextEditingController(text: medicament.nbrPacket.toString());

    await showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Update or Delete Medicament'),
          content: SingleChildScrollView(
            child: Column(
              children: [
                TextField(
                  controller: nomController,
                  decoration: InputDecoration(labelText: 'Nom'),
                ),
                TextField(
                  controller: posologieController,
                  decoration: InputDecoration(labelText: 'Posologie'),
                ),
                TextField(
                  controller: dateDController,
                  decoration: InputDecoration(labelText: 'DateD'),
                ),
                TextField(
                  controller: dosageController,
                  decoration: InputDecoration(labelText: 'Dosage'),
                ),
                TextField(
                  controller: prixController,
                  decoration: InputDecoration(labelText: 'Prix'),
                  keyboardType: TextInputType.number,
                ),
                TextField(
                  controller: datePController,
                  decoration: InputDecoration(labelText: 'DateP'),
                ),
                TextField(
                  controller: nbrPacketController,
                  decoration: InputDecoration(labelText: 'NbrPacket'),
                  keyboardType: TextInputType.number,
                ),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: Text('Update'),
              onPressed: () async {
                Medicament updatedMedicament = Medicament(
                  id: medicament.id,
                  nom: nomController.text,
                  posologie: posologieController.text,
                  dateD: dateDController.text,
                  dosage: dosageController.text,
                  prix: double.parse(prixController.text),
                  dateP: datePController.text,
                  nbrPacket: int.parse(nbrPacketController.text),
                );
                await DatabaseHelper().updateMedicament(updatedMedicament);
                Navigator.of(context).pop();
                _refreshMedicamentList();
              },
            ),
            TextButton(
              child: Text('Delete'),
              onPressed: () async {
                await DatabaseHelper().deleteMedicament(medicament.id!);
                Navigator.of(context).pop();
                _refreshMedicamentList();
              },
            ),
          ],
        );
      },
    );
  }
}
