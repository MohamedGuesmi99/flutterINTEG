import 'package:flutter/material.dart';

import 'database_helper.dart';


class StockPage extends StatelessWidget {
  final Medicament? medicament;

  StockPage({this.medicament});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Stock Page'),
        backgroundColor: Colors.teal.shade400,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (medicament != null)
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'Nom: ${medicament!.nom}',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 24),
                  ),
                  SizedBox(height: 15),
                  Text(
                    'Stock: ${medicament!.nbrPacket}',
                    style: TextStyle(fontSize: 18),
                  ),
                  SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () {
                      showReplenishDialog(context);
                    },
                    style: ButtonStyle(
                      backgroundColor:
                      MaterialStateProperty.all<Color>(Colors.teal.shade400),
                    ),
                    child: Text('Replenish Stock'),
                  ),
                ],
              )
            else
              Text('No selected medicament'),
          ],
        ),
      ),
    );
  }

  void showReplenishDialog(BuildContext context) {
    TextEditingController replenishController = TextEditingController();

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Replenish Stock'),
          content: TextField(
            controller: replenishController,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(labelText: 'Enter stock quantity'),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                // Add your logic for handling replenish here
                String replenishQuantity = replenishController.text;
                print('Replenish Quantity: $replenishQuantity');
                Navigator.of(context).pop();
              },
              child: Text('Submit'),
            ),
          ],
        );
      },
    );
  }
}

