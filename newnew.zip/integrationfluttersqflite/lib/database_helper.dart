import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class Medicament {
  int? id;
  String nom;
  String posologie;
  String dateD;
  String dosage;
  double prix;
  String dateP;
  int nbrPacket;
  int? idOrd;

  Medicament({
    this.id,
    required this.nom,
    required this.posologie,
    required this.dateD,
    required this.dosage,
    required this.prix,
    required this.dateP,
    required this.nbrPacket,
    this.idOrd,
  });

  // Convert a Medicament object into a Map
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'nom': nom,
      'posologie': posologie,
      'dateD': dateD,
      'dosage': dosage,
      'prix': prix,
      'dateP': dateP,
      'nbrPacket': nbrPacket,
      'idOrd': idOrd,
    };
  }

  // Convert a Map into a Medicament object
  factory Medicament.fromMap(Map<String, dynamic> map) {
    return Medicament(
      id: map['id'],
      nom: map['nom'],
      posologie: map['posologie'],
      dateD: map['dateD'],
      dosage: map['dosage'],
      prix: map['prix'],
      dateP: map['dateP'],
      nbrPacket: map['nbrPacket'],
      idOrd: map['idOrd'],
    );
  }

  factory Medicament.fromJson(Map<String, dynamic> json) {
    return Medicament(
      id: json['id'] as int?,
      nom: json['nom'],
      posologie: json['posologie'],
      dateD: json['dateD'],
      dosage: json['dosage'],
      prix: json['prix'],
      dateP: json['dateP'],
      nbrPacket: json['nbrPacket'],
      idOrd: json['idOrd'],
    );
  }
}

class DatabaseHelper {
  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await initDatabase();
    return _database!;
  }

  Future<Database> initDatabase() async {
    final path = join(await getDatabasesPath(), 'medicaments_database.db');
    return await openDatabase(path, version: 1, onCreate: (db, version) async {
      await db.execute('''
        CREATE TABLE medicaments(
          id INTEGER PRIMARY KEY,
          nom TEXT,
          posologie TEXT,
          dateD TEXT,
          dosage TEXT,
          prix REAL,
          dateP TEXT,
          nbrPacket INTEGER,
          idOrd INTEGER,
          FOREIGN KEY (idOrd) REFERENCES ordonnance(id)
        )
      ''');
    });
  }

  Future<int> insertMedicament(Medicament medicament) async {
    final db = await database;
    return await db.insert('medicaments', medicament.toMap());
  }

  Future<List<Medicament>> getMedicaments() async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query('medicaments');
    return List.generate(maps.length, (i) {
      return Medicament.fromMap(maps[i]);
    });
  }

  Future<int> updateMedicament(Medicament medicament) async {
    final db = await database;
    return await db.update('medicaments', medicament.toMap(), where: 'id = ?', whereArgs: [medicament.id]);
  }

  Future<int> deleteMedicament(int id) async {
    final db = await database;
    return await db.delete('medicaments', where: 'id = ?', whereArgs: [id]);
  }
}
